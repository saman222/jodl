﻿<?php
$string['messagedesc'] = 'Nachricht senden, wenn der Nutzer den Kurs noch nicht gekauft hat';
$string['enrolname'] = 'Joomdle';
$string['description'] = 'Eine Meldung anzeigen, die dem Nutzer auffordert den Kurs über Joomla.\nVersion 0.24 zu kaufen';
?>
